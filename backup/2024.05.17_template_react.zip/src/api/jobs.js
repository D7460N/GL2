import axios from 'axios'
import { getToken } from './keycloak'

// TODO: Enable typescript
export function getJobList() { //: Promise<void> {
  return getToken().then((token) => {
    // TODO: Centralized headers
    let headers = {
      'Content-Type': 'application/json',
      "Authorization": token,
    }

    let jobs_url = 'https://kong.application_name-test.env/job/list'
    const jobConfig = { //: AxiosRequestConfig = {
      headers: headers,
    }
    return axios.get(jobs_url, jobConfig)
  })
}

export function getJobDetails(jobId, data) { //: string): Promise<void> {
  return getToken().then((token) => {
    // TODO: Centralized headers
    let headers = {
      'Content-Type': 'application/json',
      "Authorization": token,
    }

    let jobsPayload = { 'body': { 'date': data, 'job_id': jobId } }
    let jobs_url = 'https://kong.application_name-test.env/job/list'
    const jobConfig = {
      headers: headers,
      data: jobsPayload
    }
    return axios.post(jobs_url, jobsPayload, jobConfig)
  })
}