import React, { useEffect, useRef } from "react";
import axios from "axios";
import cytoscape from "cytoscape";

const Graph = ({ url }) => {
  const cyRef = useRef(null);

  useEffect(() => {
    axios
      .get('/assets/data/results.json')
      .then((response) => {
        const data = response.data;
        if (!data || !Array.isArray(data)) {
          console.error("Graph data is missing or not in an array format.");
          return;
        }

        const elements = data.flatMap((item) => {
          if (item.in && item.out && item.edge) {
            return [
              { data: { id: item.in.vid, label: item.in.vtype } },
              { data: { id: item.out.vid, label: item.out.vtype } },
              {
                data: {
                  id: `e${item.in.vid}-${item.out.vid}`,
                  source: item.in.vid,
                  target: item.out.vid,
                  label: item.edge.etype,
                },
              },
            ];
          } else {
            console.error("Invalid item structure:", item);
            return [];
          }
        });

        if (elements.length === 0) {
          console.error("No valid elements to render.");
          return;
        }

        const cy = cytoscape({
          container: cyRef.current,
          elements: elements,
          style: [
            {
              selector: "node",
              style: {
                "background-color": "#666",
                label: "data(label)",
              },
            },
            {
              selector: "edge",
              style: {
                width: 3,
                "line-color": "#ccc",
                "target-arrow-color": "#ccc",
                "target-arrow-shape": "triangle",
                "curve-style": "bezier",
                label: "data(label)",
              },
            },
          ],
          layout: {
            name: "grid",
            rows: 1,
          },
        });

        return () => cy.destroy();
      })
      .catch((error) => {
        console.error("Error fetching graph data:", error);
      });
  }, [url]); // Dependency on URL to re-run the effect if the URL changes

  return <div ref={cyRef} style={{ width: "800px", height: "600px" }} />;
};

export default Graph;
