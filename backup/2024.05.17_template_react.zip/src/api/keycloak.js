import Keycloak, { KeycloakInitOptions } from 'keycloak-js';

let initialized = false;
let authentication_promise;

// TODO: Cache token or call this on page load and store the token in some provider
// TODO: Look at Keycloak performance, this takes 8 seconds to get the token currently
// TODO: Enable typescript

export function getToken() {
  if (!initialized) {
    let keycloak = new Keycloak({
      url: 'https://keycloak.application_name-test.env/',
      realm: 'coolness',
      clientId: 'integration-portal',
    });

    let initOptions = { //: KeycloakInitOptions = {
      enableLogging: true,
      onLoad: 'check-sso',
      checkLoginIframe: false, // Removed when keycloak frame-ancestors property set for localhost:3000
    };

    const authenticated = keycloak?.init(initOptions);
    // TODO: Address potential race condition here
    initialized = true;

    authenticated_promise = authenticated.then((val) => {
      if (keycloak.token !== undefined) {
        console.log("Authenticated - Token: " + keycloak.token);
        return keycloak.token;
      }
      debugger;
      throw new Error("Authentication failed");
    });

    return authentication_promise;
  } else {
    return authentication_promise;
  }
}
