import React, { useEffect, useState } from 'react';
import CytoscapeComponent from 'react-cytoscapejs';

function Graph() {
  const [elements, setElements] = useState([]);

  useEffect(() => {
    fetch('/assets/data/graph.json')
      .then(res => res.json())
      .then(data => {
        const nodes = [];
        const edges = [];
        const addedNodes = new Set();

        Object.values(data).forEach(item => {
          const inNode = {
            data: { id: item.in.vuuid[0], label: item.in.vtype[0] }
          };
          const outNode = {
            data: { id: item.out.vuuid[0], label: item.out.vtype[0] }
          };

          // Add nodes if they haven't been added already to prevent duplicates
          if (!addedNodes.has(inNode.data.id)) {
            nodes.push(inNode);
            addedNodes.add(inNode.data.id);
          }
          if (!addedNodes.has(outNode.data.id)) {
            nodes.push(outNode);
            addedNodes.add(outNode.data.id);
          }

          // Add edge
          edges.push({
            data: {
              id: `e-{item.in.vuuid[0]}-${item.out.vuuid[0]}`,
              source: item.in.vuuid[0],
              target: item.out.vuuid[0],
              label: item.edge.etype
            }
          });
        });

        setElements([...nodes, ...edges]);
      })
      .catch(error => console.error('Error loading the graph data:', error));
  }, []);

  const layout = {
    name: 'grid',
    padding: 10
  };

  const style = [
    {
      selector: 'node',
      style: {
        'background-color': '#666',
        'label': 'data(label)',
        'text-valign': 'center',
        'color': '#fff',
        'text-outline-width': '2',
        'text-outline-color': '#666'
      }
    },
    {
      selector: 'edge',
      style: {
        'width': 3,
        'line-color': '#ccc',
        'target-arrow-color': '#ccc',
        'target-arrow-shape': 'triangle',
        'curve-style': 'bezier',
        'label': 'data(label)',
        'text-margin-y': '-10'
      }
    }
  ];

  return (
    <div className="graph-container">
      <CytoscapeComponent
        elements={elements}
        layout={layout}
        stylesheet={style}
      />
    </div>
  );
}

export default Graph;
