import React, { useContext, useEffect } from 'react';
import { JsonDataContext } from './JsonDataContext';

const JsonToArrayComponent = ({ jsonData }) => {
  const { setJsonData } = useContext(JsonDataContext);

  useEffect(() => {
    const parseJson = async () => {
      try {
        const dataObject = JSON.parse(jsonData);
        setJsonData(dataObject); // Save parsed data to context
      } catch (error) {
        console.error("Failed to parse JSON data: ", error);
      }
    };

    parseJson();
  }, [jsonData, setJsonData]);

  return null; // This component does not need to render anything
};

export default JsonToArrayComponent;
