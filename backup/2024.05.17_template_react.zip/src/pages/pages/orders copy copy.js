import React, { useState } from 'react';
import { Card, CardHeader, CardExpandToggler, CardBody } from '../../components/card/card.jsx';
import searchHistory from '../../data/searchHistory.json';
import searchDatasets from '../../../src/data/datasets.json';
import searchFaqs from '../../../src/data/faqs.json';
// import tokenData from '../../../src/data/token.json';
import '../../../src/index.css';

function ItemSearch() {
  // States
  const [searchInput, setSearchInput] = useState('');
  const [searchResults, setSearchResults] = useState(null);
  const [selectedItem, setSelectedItem] = useState(null);
  // const [searchStats, setSearchStats] = useState({ count: 0, time: 0 });
  // const [isLoading, setIsLoading] = useState(false);
  // const [error, setError] = useState(null);

  const handleSearchChange = (e) => {
    setSearchInput(e.target.value);
  };

  const handleSearch = () => {

    // Check the raw input
    console.log('Starting search with input:', searchInput);

    // Record the start time of the search
    const startTime = performance.now();

    if (!searchInput.trim()) {
      setSearchResults([]);

      // Reset stats if no input
      setSearchStats({ count: 0, time: 0 });

      console.log('No input provided. Search aborted.');
      return;
    }

    // Normalize input and log it
    // Split the input to handle multiple selectors
    // const normalizedInput = searchInput.replace(/[^0-9a-zA-Z ]/g, '').split(' ').filter(Boolean);
    const entries = Object.values(searchHistory);
    // const results = entries.filter(item =>
    //   normalizedInput.some(input =>
    //     item.in.vid.some(vid => vid.includes(input))
    //   )
    // );

    // if (!results.length) {
    //   setError("No results found for the given input.");
    //   setIsLoading(false);
    //   setSearchResults([]);
    //   console.log('No results found.');
    //   return;
    // }

    // console.log('Normalized Input:', normalizedInput);
    // console.log('Number of Search Results:', results.length);

    // Assuming 'searchHistory' is defined and properly imported
    if (!searchHistory) {
      console.log('searchHistory source is not defined or is empty');
      return;
    }

    // Record the end time of the search
    const endTime = performance.now();

    console.log('Search completed in:', endTime - startTime, 'milliseconds');

    // Update the state with the search results
    setSearchResults(entries);

    // setSearchStats({ count: results.length, time: endTime - startTime });

    // setError(null); //Clear any previous errors

    // Save search to local storage for history tracking
    // const history = JSON.parse(localStorage.getItem('searchHistory')) || [];
    // history.push({
    //   searchInput,
    //   resultsCount: results.length,
    //   searchTime: endTime - startTime,
    //   date: new Date().toISOString()
    // });
    // Save the updated history back to local
    localStorage.setItem('searchHistory', JSON.stringify(history));
  };

  // old? const searchResults = performSearch();

  // Handle selection of an item to display in the second <Card>
  const handleSelectedItem = (item) => {

    // If the same item is clicked again, clear selection
    if (selectedItem && selectedItem === item) {
      setSelectedItem(null);
    } else {

      // Otherwise, update the selected item
      setSelectedItem(item);
    }
  };

  return (
    <div>
      <div className="mb-md-4 mb-3 d-md-flex">
        <div className="mt-md-0 mt-2"><a href="#/" className="text-inverse text-opacity-75 text-decoration-none"><i className="fa fa-download fa-fw me-1 text-theme"></i> Export</a></div>
        <div className="ms-md-4 mt-md-0 mt-2 dropdown-toggle">
          <a href="#/" data-bs-toggle="dropdown" className="text-inverse text-opacity-75 text-decoration-none">More Actions</a>
          <div className="dropdown-menu">
            <a className="dropdown-item" href="#/">Action</a>
            <a className="dropdown-item" href="#/">Another action</a>
            <a className="dropdown-item" href="#/">Something else here</a>
            <div role="separator" className="dropdown-divider"></div>
            <a className="dropdown-item" href="#/">Separated link</a>
          </div>
        </div>
      </div>

      <div className="row gx-4">
        <div className={`col-lg-8 ${selectedItem ? '' : 'col-lg-12'}`}>
          <Card className="mb-4">
            <ul className="nav nav-tabs nav-tabs-v2 px-4">
              <li className="nav-item me-3"><a href="#searchTab" className="nav-link active px-2" data-bs-toggle="tab">Selector Search</a></li>
              <li className="nav-item me-3"><a href="#historyTab" className="nav-link px-2" data-bs-toggle="tab">History</a></li>
              <li className="nav-item me-3"><a href="#datasetsTab" className="nav-link px-2" data-bs-toggle="tab">Datasets</a></li>
              <li className="nav-item me-3"><a href="#faqTab" className="nav-link px-2" data-bs-toggle="tab">FAQ</a></li>
              <li className="nav-item me-3"><a href="#settingsTab" className="nav-link px-2" data-bs-toggle="tab">Settings</a></li>
            </ul>
            <div className="tab-content-flex tab-content p-4">
              <div className="tab-pane fade show active" id="searchTab">
                <p>Enter one or more space delimited selectors or drag/drop a CSV file for bulk.</p>
                <div className="input-group mb-4">
                  <div className="flex-fill position-relative">
                    <div className="input-group">
                      <input
                        type="text"
                        className="form-control px-35px"
                        placeholder="Enter one or more space delimited selectors . . ."
                        value={searchInput}
                        onChange={handleSearchChange}
                        onKeyDown={(event) => {
                          if (event.key == 'Enter') {
                            handleSearch();
                          }
                        }}
                      />
                      <div className="input-group-text position-absolute top-0 bottom-0 bg-none border-0 start-0" style={{ zIndex: 1020 }}>
                        <i className="fa fa-search opacity-5"></i>
                      </div>
                    </div>
                  </div>
                  <button className="btn btn-outline-default dropdown-toggle rounded-0" type="button" data-bs-toggle="dropdown"><span className="d-none d-md-inline">Advanced</span><span className="d-inline d-md-none"><i className="fa fa-credit-card"></i></span> &nbsp;</button>
                  <div className="dropdown-menu">
                    <a className="dropdown-item" href="#/">graph_walker</a>
                    <a className="dropdown-item" href="#/">degrees</a>
                    <a className="dropdown-item" href="#/">supernode</a>
                    <div role="separator" className="dropdown-divider"></div>
                    <a className="dropdown-item" href="#/">Separated link</a>
                  </div>
                  <button className="btn btn-outline-default dropdown-toggle" type="button" data-bs-toggle="dropdown"><span className="d-none d-md-inline">Upload CSV</span><span className="d-inline d-md-none"><i className="fa fa-check"></i></span> &nbsp;</button>
                  <div className="dropdown-menu dropdown-menu-end">
                    <a className="dropdown-item" href="#/">Action</a>
                    <a className="dropdown-item" href="#/">Another action</a>
                    <a className="dropdown-item" href="#/">Something else here</a>
                    <div role="separator" className="dropdown-divider"></div>
                    <a className="dropdown-item" href="#/">Separated link</a>
                  </div>
                </div>

                <div class="intro row">
                  <h1>Welcome to GL2!</h1>
                  <p>GL2 introduces more datasets with less complexity.</p>
                </div>

                {/* <div className="error-message">
                  {error && <p className="text-danger">{error}</p>}
                </div> */}

                <div className="table-responsive responsive-flex">
                  <table className="table table-hover table-borderless text-nowrap">
                    <thead>
                      <tr>
                        <th className="border-top-0 pt-0 pb-2">Input ID</th>
                        <th className="border-top-0 pt-0 pb-2">Type</th>
                        <th className="border-top-0 pt-0 pb-2">1st Seen</th>
                        <th className="border-top-0 pt-0 pb-2">Last Seen</th>
                        <th className="border-top-0 pt-0 pb-2">Count</th>
                        <th className="border-top-0 pt-0 pb-2">Dataset</th>
                        <th className="border-top-0 pt-0 pb-2">Selector A</th>
                        <th className="border-top-0 pt-0 pb-2">Selector B</th>
                      </tr>
                    </thead>
                    <tbody>
                      {searchResults.map((item, index) => (
                        <tr
                          key={index}
                          onClick={() => setSelectedItem(item === item ? null : item)}
                          className={selectedItem === item ? 'active' : ''}
                          style={{ cursor: 'pointer' }}
                        >
                          <td className="align-middle">{item.in.vid}</td>
                          <td className="align-middle">{item.in.vtype}</td>
                          <td className="align-middle">{item.edge.firstseen}</td>
                          <td>{item.edge.lastseen}</td>
                          <td className="py-1 align-middle"><span className="badge border border-success text-success px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center"><i className="fa fa-circle fs-9px fa-fw me-5px"></i> {item.edge.ecount}</span></td>
                          <td className="align-middle"><span className="badge border border-success text-success px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center"><i className="fa fa-circle fs-9px fa-fw me-5px"></i> {item.edge.esource}</span></td>
                          <td className="align-middle">{item.out.vid}</td>
                          <td className="align-middle">{item.out.vuuid}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                {/* TODO
                      <div className="d-md-flex align-items-center">
                  <div className="me-md-auto text-md-left text-center mb-2 mb-md-0">
                    Showing 1 to 10 of 57 entries
                  </div>
                  <ul className="pagination mb-0 justify-content-center">
                    <li className="page-item disabled"><a className="page-link" href="#/">Previous</a></li>
                    <li className="page-item"><a className="page-link" href="#/">1</a></li>
                    <li className="page-item active"><a className="page-link" href="#/">2</a></li>
                    <li className="page-item"><a className="page-link" href="#/">3</a></li>
                    <li className="page-item"><a className="page-link" href="#/">4</a></li>
                    <li className="page-item"><a className="page-link" href="#/">5</a></li>
                    <li className="page-item"><a className="page-link" href="#/">6</a></li>
                    <li className="page-item"><a className="page-link" href="#/">Next</a></li>
                  </ul>
                </div> */}
              </div>

              <div className="tab-pane fade show" id="historyTab">
                <h2>History coming soon</h2>
              </div>

              <div className="tab-pane fade show" id="datasetsTab">
                <h2>Datasets</h2>
                <div className="table-responsive">
                  <table className="table table-hover table-borderless text-nowrap">
                    <thead>
                      <tr>
                        <th className="border-top-0 pt-0 pb-2">Dataset</th>
                        <th className="border-top-0 pt-0 pb-2">Type</th>
                        <th className="border-top-0 pt-0 pb-2">Org</th>
                        <th className="border-top-0 pt-0 pb-2">Status</th>
                        <th className="border-top-0 pt-0 pb-2">Actionability</th>
                        <th className="border-top-0 pt-0 pb-2">Date Range</th>
                        <th className="border-top-0 pt-0 pb-2">Correlations</th>
                        <th className="border-top-0 pt-0 pb-2">Communications</th>
                        <th className="border-top-0 pt-0 pb-2">Total</th>
                      </tr>
                    </thead>
                    <tbody>
                      {Object.values(searchDatasets).map((item, index) => (
                        <tr key={index}>
                          <td className="align-middle">{item.dataset}</td>
                          <td className="align-middle">{item.id}</td>
                          <td className="align-middle">{item.type}</td>
                          <td className="align-middle">{item.org}</td>
                          <td className="align-middle"><span className="badge border border-success text-success px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">{item.status}</span></td>
                          <td className="align-middle">{item.actionability}</td>
                          <td className="align-middle">{item.earliest_load_date} - {item.latest_load_date}</td>
                          <td className="align-middle">{item.total_weight}</td>
                          <td className="align-middle">{item.dataset.total_users}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="tab-pane fade show" id="faqTab">
                <h2>FAQ</h2>
                <p>FAQ explanation</p>
                <div className="accordion" id="faqAccordion">
                  {Object.entries(searchFaqs).map(([header, faqs], sectionIndex) => (
                    <div key={sectionIndex}>
                      <h2>{header}</h2>
                      <div className="accordion" id={`section${sectionIndex}Accordion`}>
                        {searchFaqs.map((faq, index) => (
                          <div className="accordion-item" key={index}>
                            <h2 className="accordion-header" id={`heading${sectionIndex}-${index}`}>
                              <button className="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target={`#collapse${sectionIndex}-${index}`}>
                                {faq.question}
                              </button>
                            </h2>
                            <div id={`collapse${sectionIndex}-${index}`} className="accordion-collapse collapse" aria-labelledby={`heading${sectionIndex}-${index}`} data-bs-parent={`#section${sectionIndex}Accordion`}>
                              <div className="accordion-body">
                                {faq.answer}
                                {faq.link && <a href={faq.link.href}>{faq.link.label}</a>}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="tab-pane fade show" id="settingsTab">
                <h2>Settings</h2>
              </div>

            </div>
          </Card>
        </div>

        <div className={`col-lg-4 ${selectedItem ? '' : 'd-none'}`}>
          <Card className="mb-4">
            <CardHeader className="fw-bold small-flex">
              <span className="flex-grow-1">DETAILS</span>
              <CardExpandToggler />
            </CardHeader>
            <CardBody>
              {selectedItem ? (
                <>
                  <h5 className="card-title">{selectedItem.in.vid}</h5>
                  <h6 className="card-subtitle mb-3 text-white text-opacity-50">Card subtitle</h6>
                  <p className="card-text mb-3"><strong>Type:</strong> {selectedItem.in.vtype}</p>
                  <p className="card-text mb-3"><strong>First Seen:</strong> {selectedItem.edge.firstseen}</p>
                  <p className="card-text mb-3"><strong>Last Seen:</strong> {selectedItem.edge.lastseen}</p>
                  <p className="card-text mb-3"><strong>Count:</strong> {selectedItem.edge.ecount}</p>
                  <p className="card-text mb-3"><strong>Source:</strong> {selectedItem.edge.esource}</p>
                  <p className="card-text mb-3"><strong>Vendor ID (Out):</strong> {selectedItem.out.vid}</p>
                  <p className="card-text mb-3"><strong>UUID (Out):</strong> {selectedItem.out.vuuid}</p>
                  <div>
                    <a href="#/" className="card-link">Card link</a>
                    <a href="#/" className="card-link">Another link</a>
                  </div>
                </>
              ) : (
                <div className="card-body">
                  <p>No item selected</p>
                </div>
              )}
            </CardBody>
          </Card>
        </div>
      </div>
    </div>
  );
}

export default ItemSearch;