import React from 'react';

export const AppSettings = React.createContext();