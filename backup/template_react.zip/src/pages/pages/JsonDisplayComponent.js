import React, { useContext } from 'react';
import { JsonDataContext } from './JsonDataContext';

const DisplayComponent = () => {
  const { jsonData } = useContext(JsonDataContext);

  return (
    <div>
      <pre>{JSON.stringify(jsonData, null, 2)}</pre>
    </div>
  );
};

export default DisplayComponent;
