import React, { useEffect } from 'react';
import axios from 'axios';

const FetchParseData = ({ url, onDataReceived }) => {
  const [data, setData] = useState([]);

  useEffect(() => {
    axios.get(url)
      .then(response => {
        setData(response.data);
        if (onDataReceived) {
          onDataReceived(response.data);
        }
      })
      // Handle error state
      .catch(error => {
        console.error('Error fetching data:', error);
        // Optionally handle the error if you choose to introduce error handling later
      });
  }, [url, onDataReceived]);

  // Return null or keep empty since this is purely for data-fetching
  return null;
};

export default FetchParseData;
