import React, { createContext, useState, useEffect } from 'react';
import axios from 'axios';

export const JsonDataContext = createContext({});

export const JsonDataProvider = ({ children }) => {
  const [jsonData, setJsonData] = useState([]);
  const [searchInput, setSearchInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const fetchData = async () => {
    if (!searchInput) return;  // Optionally skip fetching when input is empty
    setLoading(true);
    try {
      const response = await axios.get(`/data/searchResults.json`, {
        params: { query: searchInput }
      });
      setJsonData(Array.isArray(response.data) ? response.data : []);
      setError(null);
    } catch (err) {
      console.error("Failed to fetch data:", err);
      setError(err);
    } finally {
      setLoading(false);
    }
  };

  // Expose context values
  return (
    <JsonDataContext.Provider value={{ jsonData, loading, error, fetchData, setSearchInput }}>
      {children}
    </JsonDataContext.Provider>
  );
};
