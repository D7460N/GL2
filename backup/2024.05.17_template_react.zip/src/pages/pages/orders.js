import React, { useState, useEffect, useContext } from 'react';
import axios from 'axios';
import Graph from '../../components/graph/graph.jsx';
import { Card, CardHeader, CardExpandToggler, CardBody } from '../../components/card/card.jsx';
import { Icon } from '@iconify/react';
import '../../../src/index.css';
import { search } from '../../api/search';
import { getJobList, getJobDetails } from '../../api/jobs';

function PageItems() {
  const [searchInput, setSearchInput] = useState('');
  const [results, setResults] = useState([]);
  const [history, setHistory] = useState([]);
  const [datasets, setDatasets] = useState([]);
  const [settings, setSettings] = useState([]);
  const [faqs, setFaqs] = useState([]);
  const [selectedItem, setSelectedItem] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Utility: fetch data
  const fetchData = async (endpoint, setter) => {
    try {
      const response = await axios.get(`/assets/data/${endpoint}.json`);
      // Convert object to array if necessary
      const data = response.data;
      if (data && typeof data === 'object' && !Array.isArray(data)) {
        // Handle JSON objects with numeric keys
        setter(Object.values(data));
      } else {
        setter(Array.isArray(data) ? data : []);
      }
      console.log(`Successfully loaded ${endpoint}:`, data)
    } catch (error) {
      console.error(`Failed to load ${endpoint}:`, error);
      setError(error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData('history', data => setHistory(Array.isArray(data) ? data : [data]));
    fetchData('datasets', data => setDatasets(Array.isArray(data) ? data : [data]));
    fetchData('settings', data => setSettings(Array.isArray(data) ? data : [data]));
    fetchData('faqs', data => setFaqs(Array.isArray(data) ? data : [data]));
  }, []);

  const handleSearchChange = (e) => {
    setSearchInput(e.target.value);
  };

  const fetchResults = async () => {
    try {
      const { data } = await axios.get('/assets/data/results.json', { params: { query: searchInput } });
      setResults(Array.isArray(data) ? data : [data]);
      console.log('Successfully loaded results', data)
    } catch (error) {
      console.error('Failed to fetch search results:', error);
    }
  };

  const fetchHistory = async () => {
    try {
      const { data } = await axios.get('/assets/data/history.json');
      setHistory(Array.isArray(data) ? data : [data]);
    } catch (error) {
      console.error('Failed to fetch search history:', error);
    }
  };

  const fetchDatasets = async () => {
    try {
      const { data } = await axios.get('/assets/data/datasets.json');
      setDatasets(Array.isArray(data) ? data : [data]);
    } catch (error) {
      console.error('Failed to fetch searchable datasets:', error);
    }
  };

  const fetchSettings = async () => {
    try {
      const { data } = await axios.get('/assets/data/settings.json');
      setSettings(Array.isArray(data) ? data : [data]);
    } catch (error) {
      console.error('Failed to fetch settings:', error);
    }
  };

  const fetchFaqs = async () => {
    try {
      const { data } = await axios.get('/assets/data/faqs.json');
      setFaqs(Array.isArray(data) ? data : [data]);
    } catch (error) {
      console.error('Failed to fetch FAQs:', error);
    }
  };

  // Fetch data on component mount
  useEffect(() => {
    fetchHistory();
    fetchDatasets();
    fetchSettings();
    fetchFaqs();
  }, []);

  const handleKeyDown = (event) => {
    if (event.key === 'Enter') {
      event.preventDefault();
      console.log('Enter Key pressed. Initiating search...');
      fetchResults();
    }
  };

  const handleSearchClick = () => {
    console.log('Search button clicked.');
    fetchResults();
  }

  // Handle item selection in JSX structure below
  const handleSelectedItem = (item) => {
    setSelectedItem(selectedItem === item ? null : item);
  };

  // CSS replaces .intro when results are null
  // if (loading) return <div>Loading...</div>;
  // if (error) return <div>Error loading data!</div>;

  return (
    <div>
      <div className="mb-md-4 mb-3 d-md-flex">
        <div className="mt-md-0 mt-2"><a href="#/" className="text-inverse text-opacity-75 text-decoration-none"><i className="fa fa-download fa-fw me-1 text-theme"></i> Export</a></div>
        <div className="ms-md-4 mt-md-0 mt-2 dropdown-toggle">
          <a href="#/" data-bs-toggle="dropdown" className="text-inverse text-opacity-75 text-decoration-none">More Actions</a>
          <div className="dropdown-menu">
            <a className="dropdown-item" href="#/">Action</a>
            <a className="dropdown-item" href="#/">Another action</a>
            <a className="dropdown-item" href="#/">Something else here</a>
            <div role="separator" className="dropdown-divider"></div>
            <a className="dropdown-item" href="#/">Separated link</a>
          </div>
        </div>
      </div>

      <div className="row gx-4">
        <div className={`col-lg-8 ${selectedItem ? '' : 'col-lg-12'}`}>
          <Card className="mb-4">
            <ul className="nav nav-tabs nav-tabs-v2 px-4">
              <li className="nav-item me-3"><a href="#searchTab" className="nav-link active px-2" data-bs-toggle="tab">Selector Search</a></li>
              <li className="nav-item me-3"><a href="#historyTab" className="nav-link px-2" data-bs-toggle="tab">History</a></li>
              <li className="nav-item me-3"><a href="#datasetsTab" className="nav-link px-2" data-bs-toggle="tab">Datasets</a></li>
              <li className="nav-item me-3"><a href="#faqTab" className="nav-link px-2" data-bs-toggle="tab">FAQ</a></li>
              <li className="nav-item me-3"><a href="#settingsTab" className="nav-link px-2" data-bs-toggle="tab">Settings</a></li>
            </ul>
            <div className="tab-content-flex tab-content p-4">
              <div className="tab-pane fade show active" id="searchTab">
                <p>Enter one or more space delimited selectors or drag/drop a CSV file for bulk.</p>
                <div className="input-group mb-4">
                  <div className="flex-fill position-relative">
                    <div className="input-group">
                      <input
                        type="text"
                        className="form-control px-35px"
                        placeholder="Enter one or more space delimited selectors . . ."
                        value={searchInput}
                        onChange={handleSearchChange}
                        onKeyDown={handleKeyDown}
                      />
                      <div className="input-group-text position-absolute top-0 bottom-0 bg-none border-0 start-0" style={{ zIndex: 1020 }}>
                        <i className="fa fa-search opacity-5"></i>
                      </div>
                    </div>
                  </div>
                  <button onClick={handleSearchClick} className="btn btn-outline-default" type="button"><span className="d-none d-md-inline">Search</span><span className="d-inline d-md-none"><i className="fa fa-credit-card"></i></span> &nbsp;</button>
                  <button className="btn btn-outline-default dropdown-toggle rounded-0" type="button" data-bs-toggle="dropdown"><span className="d-none d-md-inline">Advanced</span><span className="d-inline d-md-none"><i className="fa fa-credit-card"></i></span> &nbsp;</button>
                  <div className="dropdown-menu">
                    <a className="dropdown-item" href="#/">graph_walker</a>
                    <a className="dropdown-item" href="#/">degrees</a>
                    <a className="dropdown-item" href="#/">supernode</a>
                    <div role="separator" className="dropdown-divider"></div>
                    <a className="dropdown-item" href="#/">Separated link</a>
                  </div>
                  <button className="btn btn-outline-default" type="button"><span className="d-none d-md-inline">Upload CSV</span><span className="d-inline d-md-none"><i className="fa fa-check"></i></span> &nbsp;</button>
                </div>

                <div className="intro row">
                  <h1>Welcome to GL2!</h1>
                  <p>GL2 introduces more datasets with less complexity.</p>
                </div>

                <div className="table-responsive responsive-flex">
                  <table className="table table-hover table-borderless text-nowrap">
                    <thead>
                      <tr>
                        <th className="border-top-0 pt-0 pb-2">Input ID</th>
                        <th className="border-top-0 pt-0 pb-2">Type</th>
                        <th className="border-top-0 pt-0 pb-2">1st Seen</th>
                        <th className="border-top-0 pt-0 pb-2">Last Seen</th>
                        <th className="border-top-0 pt-0 pb-2">Count</th>
                        <th className="border-top-0 pt-0 pb-2">Dataset</th>
                        <th className="border-top-0 pt-0 pb-2">Selector A</th>
                        <th className="border-top-0 pt-0 pb-2">Selector B</th>
                      </tr>
                    </thead>
                    <tbody>
                      {results.map((item, index) => (
                        <tr
                          key={index}
                          onClick={() => handleSelectedItem(selectedItem === item ? null : item)}
                          className={selectedItem === item ? 'active' : ''}
                          style={{ cursor: 'pointer' }}
                        >
                          <td className="align-middle">{item.in?.vid}</td>
                          <td className="align-middle">{item.in?.vtype}</td>
                          <td className="align-middle">{item.edge?.firstseen}</td>
                          <td>{item.edge?.lastseen}</td>
                          <td className="py-1 align-middle"><span className="badge border border-success text-success px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center"><i className="fa fa-circle fs-9px fa-fw me-5px"></i> {item.edge?.ecount}</span></td>
                          <td className="align-middle"><span className="badge border border-success text-success px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center"><i className="fa fa-circle fs-9px fa-fw me-5px"></i> {item.edge?.esource}</span></td>
                          <td className="align-middle">{item.out?.vid}</td>
                          <td className="align-middle">{item.out?.vuuid}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="tab-pane fade show" id="historyTab">
                <h2>History</h2>
                <div className="table-responsive">
                  <table className="table table-hover table-borderless text-nowrap">
                    <thead>
                      <tr>
                        <th className="border-top-0 pt-0 pb-2">Input ID</th>
                        <th className="border-top-0 pt-0 pb-2">Type</th>
                        <th className="border-top-0 pt-0 pb-2">1st Seen</th>
                        <th className="border-top-0 pt-0 pb-2">Last Seen</th>
                        <th className="border-top-0 pt-0 pb-2">Count</th>
                        <th className="border-top-0 pt-0 pb-2">Dataset</th>
                        <th className="border-top-0 pt-0 pb-2">Item A</th>
                        <th className="border-top-0 pt-0 pb-2">Item B</th>
                      </tr>
                    </thead>
                    <tbody>
                      {history.map((item, index) => (
                        <tr key={index}>
                          <td className="align-middle">{item.system || 'N/A'}</td>
                          <td className="align-middle">{item.attempts || 0}</td>
                          <td className="align-middle">{item.auth ? item.auth.org : 'N/A'}</td>
                          <td className="align-middle">{item.auth ? item.auth.user : 'N/A'}</td>
                          <td className="align-middle">{item.class || 'N/A'}</td>
                          <td className="align-middle">{item.failures || 0}</td>
                          <td className="align-middle">{item.inputs || 0}</td>
                          <td className="align-middle">{item.job || 'N/A'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="tab-pane fade show" id="datasetsTab">
                <h2>Datasets</h2>
                <div className="table-responsive">
                  <table className="table table-hover table-borderless text-nowrap">
                    <thead>
                      <tr>
                        <th className="border-top-0 pt-0 pb-2">Dataset</th>
                        <th className="border-top-0 pt-0 pb-2">Type</th>
                        <th className="border-top-0 pt-0 pb-2">Org</th>
                        <th className="border-top-0 pt-0 pb-2">Status</th>
                        <th className="border-top-0 pt-0 pb-2">Actionability</th>
                        <th className="border-top-0 pt-0 pb-2">Date Range</th>
                        <th className="border-top-0 pt-0 pb-2">Correlations</th>
                        <th className="border-top-0 pt-0 pb-2">Communications</th>
                        <th className="border-top-0 pt-0 pb-2">Total</th>
                      </tr>
                    </thead>
                    <tbody>
                      {datasets.map((item, index) => (
                        <tr key={index}>
                          <td className="align-middle">{item?.dataset}</td>
                          <td className="align-middle">{item?.id}</td>
                          <td className="align-middle">{item?.type}</td>
                          <td className="align-middle">{item?.org}</td>
                          <td className="align-middle"><span className="badge border border-success text-success px-2 pt-5px pb-5px rounded fs-12px d-inline-flex align-items-center">{item?.status}</span></td>
                          <td className="align-middle">{item?.actionability}</td>
                          <td className="align-middle">{item?.earliest_load_date} - {item?.latest_load_date}</td>
                          <td className="align-middle">{item?.total_weight}</td>
                          <td className="align-middle">{item?.dataset.total_users}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="tab-pane fade show" id="faqTab">
                <h2>FAQ</h2>
                <p>FAQ explanation</p>
                <div className="accordion" id="faqAccordion">
                  {Object.entries(faqs).map(([header, faqs], sectionIndex) => (
                    <div key={sectionIndex}>
                      <h2>{header}</h2>
                      <div className="accordion" id={`section${sectionIndex}Accordion`}>
                        {faqs.map((faq, index) => (
                          <div className="accordion-item" key={index}>
                            <h2
                              className="accordion-header"
                              id={`heading${sectionIndex}-${index}`}>
                              <button
                                className="accordion-button"
                                type="button"
                                data-bs-toggle="collapse"
                                data-bs-target={`#collapse${sectionIndex}-${index}`}>
                                {faq?.question}
                              </button>
                            </h2>
                            <div
                              id={`collapse${sectionIndex}-${index}`}
                              className="accordion-collapse collapse"
                              aria-labelledby={`heading${sectionIndex}-${index}`}
                              data-bs-parent={`#section${sectionIndex}Accordion`}>
                              <div className="accordion-body">
                                {faq?.answer}
                                {faq?.link && <a href={faq.link?.href}>{faq.link?.label}</a>}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="tab-pane fade show" id="settingsTab">
                <h2>Settings</h2>
                <div>
                  {settings.map((item, index) => (
                    <ul key={index}>
                      <li className="align-middle">Name: {item?.name}</li>
                      <li className="align-middle">ID: {item?.id}</li>
                      <li className="align-middle">Org: {item?.org}</li>
                    </ul>
                  ))}
                </div>
              </div>

            </div>
          </Card>
        </div>

        <div className={`col-lg-4 ${selectedItem ? '' : 'd-none'}`}>
          <Card className="mb-4">
            <CardHeader className="fw-bold small-flex">
              <span className="flex-grow-1">DETAILS</span>
              <CardExpandToggler />
            </CardHeader>
            <CardBody>
              {selectedItem ? (
                <>
                  <h5 className="card-title">{selectedItem.in?.vid}</h5>
                  <h6 className="card-subtitle mb-3 text-white text-opacity-50">Card subtitle</h6>
                  <p className="card-text mb-3"><strong>Type:</strong> {selectedItem.in?.vtype}</p>
                  <p className="card-text mb-3"><strong>First Seen:</strong> {selectedItem.edge?.firstseen}</p>
                  <p className="card-text mb-3"><strong>Last Seen:</strong> {selectedItem.edge?.lastseen}</p>
                  <p className="card-text mb-3"><strong>Count:</strong> {selectedItem.edge?.ecount}</p>
                  <p className="card-text mb-3"><strong>Source:</strong> {selectedItem.edge?.esource}</p>
                  <p className="card-text mb-3"><strong>Vendor ID (Out):</strong> {selectedItem.out?.vid}</p>
                  <p className="card-text mb-3"><strong>UUID (Out):</strong> {selectedItem.out?.vuuid}</p>
                  <div>
                    <a href="#/" className="card-link">Card link</a>
                    <a href="#/" className="card-link">Another link</a>
                  </div>
                </>
              ) : (
                <div className="card-body">
                  <p>No item selected</p>
                </div>
              )}
            </CardBody>
          </Card>
        </div>
      </div>
    </div>
  );
}

export default PageItems;