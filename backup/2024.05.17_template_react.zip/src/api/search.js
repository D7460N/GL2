import axios, { AxiosRequestConfig } from 'axios'
import { getToken } from './keycloak'

// TODO: Enable typescript
export function search(selectors) { //: string): Promise<void> {
  return getToken().then((token) => {
    // TODO: Centralized headers
    let headers = {
      'Content-Type': 'application/json',
      "Authorization": token,
    }

    let searchPayload = {
      "body": {
        "selector": selectors,
        "graphname": "gl_traversal",
        "edgestore": "gl"
      },
    }
    let url_search = 'https://kong.application_name-test.test.env/search'
    const searchConfig = {
      headers: headers,
    }
    return axios.post(url_search, searchPayload, searchConfig)
  })
}